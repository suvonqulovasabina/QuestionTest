package com.example.questiontest.presentation.MYDialog;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.example.questiontest.R;

public class MainActivity extends AppCompatActivity {
    MyDilalog myDilalog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        myDilalog=new MyDilalog();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.button_1);
        Cus
    }
}