package com.example.questiontest.presentation.MYDialog;

public interface DataEmitter {
    void show(String name);
}
