package com.example.questiontest.presentation.Scrin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.ViewGroupUtils;

import android.content.Intent;
import android.media.ImageWriter;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.questiontest.R;
import com.example.questiontest.data.madel.QuestionData;

import java.util.ArrayList;
import java.util.List;

public class MainScrin extends AppCompatActivity implements MainScrinCantract.View {
    List<ViewGroup> variantID;
    List<ImageView> imageViews;
    List<TextView> varian;
    TextView textView;
    int count=0;
    int countTrue;
    int countFalse;
    MainScrinCantract.Presinter presinter;
    Button button;
    TextView textView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
        init();
        presinter = new MainScrinpresinter(this);
    }

    private void init() {
        textView1=findViewById(R.id.son);
        button=findViewById(R.id.bt);
        textView = findViewById(R.id.text);
        variantID = new ArrayList<>();
        variantID.add(findViewById(R.id.container1));
        variantID.add(findViewById(R.id.container2));
        variantID.add(findViewById(R.id.container3));
        variantID.add(findViewById(R.id.container4));
        imageViews = new ArrayList<>();
        imageViews.add(findViewById(R.id.image_vertical1));
        imageViews.add(findViewById(R.id.image_vertical2));
        imageViews.add(findViewById(R.id.image_vertical3));
        imageViews.add(findViewById(R.id.image_vertical4));
        varian=new ArrayList<>();
        varian.add(findViewById(R.id.text1));
        varian.add(findViewById(R.id.text2));
        varian.add(findViewById(R.id.text3));
        varian.add(findViewById(R.id.text4));

        for (int i = 0; i < variantID.size(); i++) {
            int index=i;
            variantID.get(i).setOnClickListener(v -> {
                presinter.onclick(index);
            });
        }
        button.setOnClickListener(v -> presinter.ButtonOnclick());
    }


    @Override
    public void setQuestion(QuestionData question) {
      //  textView1.setText(count);
        textView.setText(question.getSavol());
        for (int i = 0; i < varian.size(); i++) {
            varian.get(i).setText(question.getVariant()[i]);
        }
    }

    @Override
    public void ButtonNext(boolean b) {
        button.setEnabled(b);
    }

    @Override
    public void ClearIcon(int index) {
        imageViews.get(index).setImageResource(R.drawable.ic_unchecked);
    }

    @Override
    public void NOClearIcon(int index) {
        imageViews.get(index).setImageResource(R.drawable.maystrelka);
    }

    @Override
    public void intCount(int current, int length) {
       textView1.setText(String.valueOf(current));
    }

    @Override
    public void onclick() {
        Intent intent=new Intent(this,MainActivity2.class);
        intent.putExtra("savol",countTrue);
        intent.putExtra("savol2",countFalse);
        startActivity(intent);
    }

    @Override
    public void count(int a, int b) {
        countTrue=a;
        countFalse=b;
    }
}