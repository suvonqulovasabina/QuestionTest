package com.example.questiontest.domain;

import com.example.questiontest.data.madel.Question;
import com.example.questiontest.data.madel.QuestionData;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AppControl {
   private static AppControl appControl;
   private static Question question;
  private static List<QuestionData>questionData=new ArrayList<>();
   private AppControl(){
   };
  static   public AppControl geInstance(){
        if (appControl==null){
            appControl=new AppControl();
        }
        return appControl;
    }
//    private Question getQuestionENAM(){
//        return question;
//    }
    public  void setQuestion(Question question){
        this.question = question;
        geQuestion();
    }
    public List<QuestionData> getQuestiondat(){
        return questionData;
    }
    private void geQuestion(){
      questionData.clear();
        switch (question){
            case MATIMATIKA:{
                questionData.add(new QuestionData("Kvadratik tenglamalar: 2x² + 5x - 3 ni yeching","4","-1","1","7","-1"));
                questionData.add(new QuestionData("Daraja funksiyalari: 3² + 4² ni hisoblang","25","27","21","7","25"));
                questionData.add(new QuestionData("Trigonometriya: sin(30°) ning qiymatini toping","3","1,5","1","0,6","0,5"));
                questionData.add(new QuestionData("Geometriya: To'g'ri burchakli uchburchakning yuzini hisoblang, uning tomonlari 5 cm va 7 cm.","3","5","6","21","21"));
                questionData.add(new QuestionData("Murakkab sonlar: 35 ning bo'luvchilarini toping.","3,6,9","1,5,6,7","6","7","1,5,6,7"));
                questionData.add(new QuestionData("vadratik tenglamalar: x² - 6x + 9 ni yeching.","9","5","6","7","9"));
                questionData.add(new QuestionData("Daraja funksiyalari: 4³ + 2² ni hisoblang","20","5","21","7","20"));
                questionData.add(new QuestionData("Trigonometriya: cos(60°) ning qiymatini toping","1","5","6","7","1"));
                questionData.add(new QuestionData("To'g'ri burchakli uchburchakning yuzini hisoblang, uning tomonlari 10 cm va 12 cm.","33","55","76","97","96"));
                questionData.add(new QuestionData("Murakkab sonlar: 42 ning bo'luvchilarini toping.","1,2,3,6,7,14,21,42","5","6,4,7","7","1,2,3,6,7,14,21,42"));
                questionData.add(new QuestionData("Daraja funksiyasi: 2² + 3³ ni hisoblang.","13","5","6","7","13"));
                questionData.add(new QuestionData("Trigonometriya: cos(60°) ning qiymatini toping","3","1","6","7","1"));
                questionData.add(new QuestionData("Geometriya: Doira yuzini hisoblang, uning radiusi 128 cm","3","5","256","7","128"));
                questionData.add(new QuestionData("Murakkab sonlar: 72 ning bo'luvchilarini toping","1, 2, 3, 4, 6, 8, 9, 12, 18, 24, 36, 72","5,6,7,8","6,90,45","7","1, 2, 3, 4, 6, 8, 9, 12, 18, 24, 36, 72"));
                questionData.add(new QuestionData("Proporsiya: 15 ta puldan 3 ta olish uchun nechta pul kerak?","3","5","4","7","4"));
                questionData.add(new QuestionData("Kvadratik tenglamalar: x² - 9x + 18 ni yeching","3","5","6","7","3"));
                questionData.add(new QuestionData("Daraja funksiyalari: 5² - 4² ni hisoblang","21","5","16","17","21"));
                questionData.add(new QuestionData("Trigonometriya: sin(45°) ning qiymatini toping","3","1","24","7","1"));
                questionData.add(new QuestionData("Geometriya: To'g'ri burchakli uchburchakning yuzini hisoblang, uning tomonlari 8 cm va 6 cm.","24","5","6","27","24"));
                questionData.add(new QuestionData("Murakkab sonlar: 48 ning bo'luvchilarini toping","3,2,4,7","5","1, 2, 3, 4, 6, 8, 12, 16, 24, 48","7,8,9","1, 2, 3, 4, 6, 8, 12, 16, 24, 48"));
                break;
            }
            case FIZIKA:{
                questionData.add(new QuestionData("Mekanika: Qalqib yuradigan ob'ektning tezlanishini hisoblash uchun qaysi formuladan foydalaniladi?","3","5","6","7","6"));
                questionData.add(new QuestionData("Isitish va termodinamika: Qay birikmali isitgich birikmali quvvatga o'zgartiradi?","3","5","6","7","5"));
                questionData.add(new QuestionData("Optika: Kichiklardan katta to'g'ri burchakli stroboskopik effektga misol?","3","5","6","7","6"));
                questionData.add(new QuestionData("Elektrika va magnetizm: Elektrik to'qimalarining bir-biriga ta'sirini qanday ifodalaydi?","3","40","6","7","40"));
                questionData.add(new QuestionData("Atom fizikasi: Elektronning joylashishi va harakatlanishi to'g'ri keluvchi qaysi atom modeliga asoslangan?","3","40","6","7","40"));
                questionData.add(new QuestionData("Mekanika: Bir ob'ektning tezlanishini hisoblash uchun qaysi formuladan foydalaniladi?","3","40","6","7","40"));
                questionData.add(new QuestionData("Isitish va termodinamika: Isitish energiyasi qaysi birlarda ifodalangan?","3","40","6","7","40"));
                questionData.add(new QuestionData("Optika: Qora tishni qora qilish uchun qaysi rang uchun joylashgan bitta tishdan foydalaniladi?","3","40","6","7","40"));
                questionData.add(new QuestionData("Elektrika va magnetizm: Elektrik to'qimalarining bir-biriga ta'siri qanday ifodalaydi?","3","40","6","7","40"));
                questionData.add(new QuestionData("Atom fizikasi: Elektronning joylashishi va harakatlanishi to'g'ri keluvchi qaysi atom modeliga asoslangan?","3","40","6","7","40"));
                questionData.add(new QuestionData("Elektr qurilmalar: Elektr energiya uzatishida foydalaniladigan element qanday?","3","40","6","7","40"));
                questionData.add(new QuestionData("Harorat va termodinamika: Harorat birikmali birikmali quvvatga o'zgartiradi.","3","40","6","7","40"));
                questionData.add(new QuestionData("Optika: Quyoshning tezlanishi katta yuza harakati tufayli yuz beradi. Bu qaysi optik effekt?","3","40","6","7","40"));
                questionData.add(new QuestionData("Atom fizikasi: Elektronning joylashishi va harakatlanishi to'g'ri keluvchi qaysi atom modeliga asoslangan?","3","40","6","7","40"));
                questionData.add(new QuestionData("Elektromagnitizm: Bir elektr stantionida generatsiya qilinayotgan kuchli elektr energiya qanday transport qilinadi?","3","40","6","7","40"));
                questionData.add(new QuestionData("Qalqib yuradigan ob'ektning tezlanishini hisoblash uchun qaysi formuladan foydalaniladi?","3","40","6","7","40"));
                questionData.add(new QuestionData("Isitish va termodinamika: Isitish energiyasining birlari qaysi birlarda ifodalangan?","3","40","6","7","40"));
                questionData.add(new QuestionData("Optika: Quyoshning tezlanishi katta yuza harakati tufayli yuz beradi. Bu qaysi optik effekt?","3","40","6","7","40"));
                questionData.add(new QuestionData("Elektrika va magnetizm: Elektrik to'qimalarining bir-biriga ta'sirini qanday ifodalaydi?","3","40","6","7","40"));
                questionData.add(new QuestionData("Atom fizikasi: Elektronning joylashishi va harakatlanishi to'g'ri keluvchi qaysi atom modeliga asoslangan?","3","40","6","7","40"));
                break;
            }
            case ONA_TILI:{
                questionData.add(new QuestionData("Qanday gaplar yig‘iq gaplar sanaladi?"," ikkinchi darajali bo‘laklar ishtirok etgan gaplar","faqat ega, kesim, to‘ldiruvchidan iborat gaplar","gapda barcha bo‘laklar ishtirok etgan gaplar"," faqat bosh bo‘laklardan iborat gaplar",""));
                questionData.add(new QuestionData(" Fe’ldan anglashilgan harakat-holatning bajarilish yoki bajarilmaslik paytini, o‘rnini, sababini, maqsadini bildiradigan bo‘lak qaysi?","ega","hol","hol"," aniqlovchi",""));
                questionData.add(new QuestionData(". Qishda yangi yilni kutamiz. Ushbu gapdagi holni toping","yangi yilni","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                questionData.add(new QuestionData("","","","","",""));
                break;

            }
            case INFORMATIKA:{
                questionData.add(new QuestionData("5*3","3","5","6","7","6"));
                questionData.add(new QuestionData("2*4","3","5","6","7","8"));
                questionData.add(new QuestionData("2*3","3","5","6","7","6"));
                questionData.add(new QuestionData("2*3","3","5","6","7","6"));
                break;
            }
            case INGILIZ_TILI:{
                questionData.add(new QuestionData("5*3","3","5","6","7","6"));
                questionData.add(new QuestionData("8*4","3","5","6","7","16"));
                questionData.add(new QuestionData("2*3","3","5","6","7","6"));
                questionData.add(new QuestionData("2*3","3","5","6","7","6"));
                break;
            }
            case RUST_TILI:{
                questionData.add(new QuestionData("5*3","3","5","6","7","6"));
                questionData.add(new QuestionData("2*4","3","5","6","7","8"));
                questionData.add(new QuestionData("2*3","3","5","6","7","6"));
                questionData.add(new QuestionData("7*3","3","5","6","7","21"));
                break;
            }
            case ADABIYIT:{
                questionData.add(new QuestionData("5*3","3","5","6","7","6"));
                questionData.add(new QuestionData("2*9","3","5","6","7","18"));
                questionData.add(new QuestionData("2*3","3","5","6","7","6"));
                questionData.add(new QuestionData("2*3","3","5","6","7","6"));
                break;
            }
        }
    }
}
