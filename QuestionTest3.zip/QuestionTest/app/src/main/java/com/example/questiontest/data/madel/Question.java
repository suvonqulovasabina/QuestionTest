package com.example.questiontest.data.madel;

public enum Question {
    MATIMATIKA, INFORMATIKA, FIZIKA, ONA_TILI, INGILIZ_TILI, RUST_TILI, ADABIYIT
}
