package com.example.questiontest.presentation.Main;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import com.example.questiontest.R;
import com.example.questiontest.data.madel.Question;
import com.example.questiontest.presentation.Scrin.MainScrin;

public class MainActivity extends AppCompatActivity implements MainContract.View{
    MainContract.Presinter presinter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        presinter=new MainPresinter(this);
        getQuestion();
    }
    @Override
    public void onClick() {
        Intent intent = new Intent(this, MainScrin.class);
        startActivity(intent);
    }
    private void getQuestion(){
        findViewById(R.id.bt1).setOnClickListener(v -> {
          presinter.setQuestion(Question.MATIMATIKA);

        });
        findViewById(R.id.bt2).setOnClickListener(v -> {
            presinter.setQuestion(Question.FIZIKA);
        });
        findViewById(R.id.bt3).setOnClickListener(v -> {
            presinter.setQuestion(Question.INFORMATIKA);
        });
        findViewById(R.id.bt4).setOnClickListener(v -> {
            presinter.setQuestion(Question.ONA_TILI);

        });
        findViewById(R.id.bt5).setOnClickListener(v -> {
            presinter.setQuestion(Question.ONA_TILI);

        });
        findViewById(R.id.bt6).setOnClickListener(v -> {
            presinter.setQuestion(Question.ONA_TILI);

        });
        findViewById(R.id.bt7).setOnClickListener(v -> {
            presinter.setQuestion(Question.ONA_TILI);

        });
    }
}